// npm install cheerio

var fs = require('fs');
var cheerio = require('cheerio');

// load the cheerio object into a variable, `content`
// which holds data and metadata about the html file (written as txt)
// use fs library
var content = fs.readFileSync('m01.txt');

// load `content` into a cheerio object
var $ = cheerio.load(content);

var meetings = [ ];

// use each selection to loop if there are many, "i" stands for index, "elem" is for element
$('tr').each(function(i, elem) {
    // "magin-bottom:10px" is there all info lives
    if ($(elem).attr("style")=="margin-bottom:10px") {
       // console.log($(elem).html());
      //  console.log('*************')
        // var thisMeeting = {}; // Your function and data collection go here! 
   logTrs($(elem).html())
    }
});


function logTrs(tr) {
    console.log(tr)
    console.log('*************')
    meetings.push(tr)
    console.log(meetings.lenght)
}

function logTds(td) {
    console.log(td)
    console.log('*************')
}



