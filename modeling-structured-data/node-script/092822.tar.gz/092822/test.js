// cheerio.js.org
var fs = require("fs");
var cheerio = require("cheerio");

// load the cheerio object into a variable, 'content'
// which holds data and metadata 
